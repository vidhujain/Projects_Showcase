import credentials
import twitter_settings
import os
import psycopg2
import imp
imp.reload(twitter_settings)
imp.reload(credentials)
from twitter_settings import *
import re
import tweepy
#import mysql.connector
#import pandas as pd
#import numpy as np
#from textblob import TextBlob
import nltk
nltk.download('vader_lexicon')
nltk.data.path.append("/libs/nltk_data/")
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import json

# Simple demo app only
import dash
app = dash.Dash(__name__)
app.title = 'Real-Time Twitter Monitor'

server = app.server

class MyStreamListener(tweepy.StreamListener):
    def on_connect(self):
        # Called initially to connect to the Streaming API
        print("You are now connected to the streaming API.")

    def on_status(self,status):

        if status.retweeted:
            ## for now avoid retweeted info
            return True

        #Extract attributes of each tweet
        id_str=status.id_str
        created_at=status.created_at
        original_text=status.text
        text=deEmojify_tweet(status.text)
        text=clean_tweet(text)

        ## use Vader to check sentiment of text
        ########################################
        print("Before vader")
        analyser = SentimentIntensityAnalyzer()
        print("After vader")
        score = analyser.polarity_scores(status.text)
        print("after score: {0}".format(score))
        if score['compound']>=0.05: #positive
            polarity = 1
        elif (score['compound']>-0.05) & (score['compound']<0.05): #neutral
            polarity = 0
        elif score['compound']<=-0.05: #negative
            polarity = -1

        compound_score=score['compound']
        positive_score=score['pos']
        negative_score=score['neg']
        neutral_score=score['neu']

        ## set subjectivity as 0 for Vader
        subjectivity = 0
        ###########################################

        ## use TextBlob to check sentiment of text
        ########################################
#         sentiment=TextBlob(text).sentiment
#         polarity=sentiment.polarity
#         subjectivity=sentiment.subjectivity
        ######################################



        hashtags = []   #make an empty list

        for hashtag in status.entities['hashtags']:    #iterate over the list
            hashtags.append(hashtag["text"])             #append each hashtag to 'hashtags'

        #usermentions_list = json.dump(user_mentions)
        user_id = status.user.id_str
        user_name = status.user.name
        user_screen_name = status.user.screen_name
        print('userId: {0}, userName: {1}, userScreenName: {2}'.format(user_id,user_name,user_screen_name))
        user_created_at = status.user.created_at
        user_location=deEmojify_tweet(status.user.location)
        user_description=deEmojify_tweet(status.user.description)

        user_friends_count = status.user.friends_count
        user_followers_count=status.user.followers_count
        user_following = status.user.following

        #------------------------------------------
        tweetFound=False
        track_val = ''
        tweet_found_count = 0

        netflix_check_list = ['Netflix','netflix']
        netflix_check_set = set(netflix_check_list)
        # appletv_check_list = ['AppleTV','Apple TV','appletv','apple tv']
        # appletv_check_set = set(appletv_check_list)
        # disney_check_list = ['DisneyPlus','Disney+','disneyplus','disney+','disney','Disney','Disneyplus']
        # disney_check_set = set(disney_check_list)
        # amazon_check_list = ['Amazon Prime Video','amazon prime video','AmazonPrimeVideo',
        #              'amazonprimevideo','AmazonPrime Video','Amazon Prime','amazon prime','amazon','prime',
        #             'Amazon','Prime']
        # amazon_check_set = set(amazon_check_list)
#         hbo_check_list = ['HBOMax','HBO Max','hbomax']
#         hbo_check_set = set(hbo_check_list)

        text_set = set(text.split())
#         if amazon_check_set.intersection(text_set):
#             track_val = 'AmazonPrime'
#             tweetFound=True
#             tweet_found_count = tweet_found_count + 1
#         if appletv_check_set.intersection(text_set):
#             track_val = 'AppleTV'
#             tweetFound=True
#             tweet_found_count = tweet_found_count + 1
#         if disney_check_set.intersection(text_set):
#             track_val = 'DisneyPlus'
#             tweetFound=True
#             tweet_found_count = tweet_found_count + 1
# #         if hbo_check_set.intersection(text_set):
# #             track_val = 'HBOmax'
# #             tweetFound=True
# #             tweet_found_count = tweet_found_count + 1
        if netflix_check_set.intersection(text_set):
            track_val = 'Netflix'
            tweetFound=True
            tweet_found_count = tweet_found_count + 1

        if (tweet_found_count > 1):
            tweetFound = False

        print('tweet Found: {0}'.format(tweetFound))

        longitude=None
        latitude=None
        if status.coordinates:
            longitude=status.coordinates['coordinates'][0]
            latitude=status.coordinates['coordinates'][1]

        retweet_count=status.retweet_count
        favorite_count=status.favorite_count

        #store all data in Heroku PostgreSQL
        cur = conn.cursor()

        sql = "INSERT INTO {} (id_str, created_at, track ,text, original_text, polarity, compound_score, negative_score, positive_score, neutral_score,subjectivity, hashtags, user_created_at, user_id, user_name, user_screen_name, user_location, user_description, user_followers_count, user_friends_count, longitude, latitude, retweet_count, favorite_count) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s ,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s) ON CONFLICT (text) DO NOTHING".format(twitter_settings.TABLE_NAME)
        val = (id_str, created_at, track_val, text, original_text, polarity, compound_score, negative_score, positive_score, neutral_score ,subjectivity, str(hashtags), user_created_at, user_id, user_name, user_screen_name, user_location, \
            user_description, user_followers_count, user_friends_count, longitude, latitude, retweet_count, favorite_count)
        cur.execute(sql, val)
        conn.commit()

        # this is to delete rows if the number of frows exceed 10,000 due to cloud basic plan limitations
        delete_query = '''
        DELETE FROM {0}
        WHERE id_str IN (
            SELECT id_str
            FROM {0}
            ORDER BY created_at asc
            LIMIT 200) AND (SELECT COUNT(*) FROM {0}) > 6000;
        '''.format(twitter_settings.TABLE_NAME)

        #delete_query='DELETE FROM {0}'.format(twitter_settings.TABLE_NAME)
        # conn.commit()

        cur.execute(delete_query)
        conn.commit()
        cur.close()

    def on_error(self, status_code):

        ##Since Twitter API has rate limits, stop scraping data as it exceed to the threshold.

        if status_code == 420:
            # return False to disconnect the stream
            return False


def clean_tweet(tweet):

    ##Use sumple regex statemnents to clean tweet text by removing links and special characters

    tweet_text= ' '.join(re.sub("(RT @[\w_]+:)|(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\S+)", " ", tweet).split())
    tweet_text = re.sub(r'(.)\1{2,}',r'\1\1',tweet_text)
    return tweet_text

def deEmojify_tweet(text):

    ##Strip all non-ASCII characters to remove emoji characters

    if text:
        return text.encode('ascii', 'ignore').decode('ascii')
    else:
        return None

DATABASE_URL= os.environ['DATABASE_URL']

conn=psycopg2.connect(DATABASE_URL,sslmode='require')
cur=conn.cursor()

'''
Check if this table exits. If not, then create a new one.
'''
'''
cur.execute("""
        SELECT COUNT(*)
        FROM information_schema.tables
        WHERE table_name = '{0}'
        """.format(twitter_settings.TABLE_NAME))
if cur.fetchone()[0] == 0:
    cur.execute("CREATE TABLE {} ({});".format(twitter_settings.TABLE_NAME, twitter_settings.TABLE_ATTRIBUTES))
    conn.commit()
cur.close()
'''

# cur.execute('DELETE FROM {0}'.format(twitter_settings.TABLE_NAME))
# conn.commit()


auth  = tweepy.OAuthHandler(credentials.API_KEY, credentials.API_SECRET_KEY)
auth.set_access_token(credentials.ACCESS_TOKEN, credentials.ACCESS_TOKEN_SECRET)
api = tweepy.API(auth)


myStreamListener = MyStreamListener()
myStream = tweepy.Stream(auth = api.auth, listener = myStreamListener)
myStream.filter(languages=["en"], track = twitter_settings.TRACK_WORDS)
# Close the MySQL connection as it finished
# However, this won't be reached as the stream listener won't stop automatically
# Press STOP button to finish the process.
conn.close()
