# import dash
# app = dash.Dash(__name__)
# server = app.server #the Flask app
import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import pandas as pd
import plotly.graph_objs as go
import twitter_settings
import itertools
import math
import base64
from flask import Flask
import os
import psycopg2
import datetime

import re
import nltk
nltk.download('punkt')
nltk.download('stopwords')
from nltk.probability import FreqDist
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from textblob import TextBlob
import nltk
nltk.download('vader_lexicon')
#nltk.data.path.append("/libs/nltk_data/")
from nltk.sentiment.vader import SentimentIntensityAnalyzer
#from nltk.sentiment.vader import SentimentIntensityAnalyzer

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.title = 'Real-Time Twitter Monitor'

server = app.server

app.layout = html.Div(children=[
    html.H2('Real-time Twitter Sentiment Analysis for Brand Improvement and Topic Tracking of \"Netflix\" brand (NASDAQ: NFLX) in Pacific Daylight Time (PDT).', style={
        'textAlign': 'center'
    }),

    # html.H3(
    #     children=[
    #         html.P("Currently tracking \"Netflix\" brand (NASDAQ: NFLX) on Twitter in Pacific Daylight Time (PDT).",
    #             style={
    #                 'fontSize': 25
    #             }
    #         ),
    #     ],
    #     style={
    #         'width': '40%',
    #         #'display': 'inline-block'
    #         'textAlign': 'center'
    #     }
    # ),

    html.Div(id='live-update-graph'),
    html.Div(id='live-update-graph-bottom'),


    dcc.Interval(
        id='interval-component-slow',
        interval=600*1000, # in milliseconds
        n_intervals=0
    )
    ], style={'padding': '20px'})



# Multiple components can update everytime interval gets fired.
@app.callback(Output('live-update-graph', 'children'),
              [Input('interval-component-slow', 'n_intervals')])
def update_graph_live(n):

    # TRACKWORDS
    track_words = ['Netflix','Disney Plus','Amazon Prime','AppleTV']
    # Loading data from Heroku PostgreSQL
    DATABASE_URL = os.environ['DATABASE_URL']
    conn = psycopg2.connect(DATABASE_URL, sslmode='require')
    query = "SELECT id_str, text, created_at, polarity, user_location, user_followers_count FROM {} WHERE track like '%Netflix%'".format(twitter_settings.TABLE_NAME)
    df = pd.read_sql(query, con=conn)


    # Convert UTC into PDT
    df['created_at'] = pd.to_datetime(df['created_at']).apply(lambda x: x - datetime.timedelta(hours=7))



    # Clean and transform data to enable time series
    result = df.groupby([pd.Grouper(key='created_at', freq='10min'), 'polarity']).count().unstack(fill_value=0).stack().reset_index()
    result = result.rename(columns={"id_str": "Num of '{}' mentions".format(track_words[0]), "created_at":"Time"})
    time_series = result["Time"][result['polarity']==0].reset_index(drop=True)

    min10 = datetime.datetime.now() - datetime.timedelta(hours=7, minutes=10)
    min20 = datetime.datetime.now() - datetime.timedelta(hours=7, minutes=20)

    print('min10: {0}'.format(min10))
    print('min20: {0}'.format(min20))

    neu_num = result[result['Time']>min10]["Num of '{}' mentions".format(track_words[0])][result['polarity']==0].sum()
    neg_num = result[result['Time']>min10]["Num of '{}' mentions".format(track_words[0])][result['polarity']==-1].sum()
    pos_num = result[result['Time']>min10]["Num of '{}' mentions".format(track_words[0])][result['polarity']==1].sum()

    print('10 min before neu count: {0}'.format(neu_num))
    print('10 min before neg count: {0}'.format(neg_num))
    print('10 min before pos count: {0}'.format(pos_num))

    # Loading back-up summary data
    tt = str((datetime.datetime.now()-datetime.timedelta(hours=7)).date())
    print('tt: {0}'.format(tt))
    #query = "SELECT count(id_str) as daily_tweets_num, sum(user_followers_count) as impressions FROM {} WHERE track like '%Netflix%' and CAST(created_at AS VARCHAR) like '{}%'".format(twitter_settings.TABLE_NAME,tt)
    query = "SELECT count(id_str) as daily_tweets_num, sum(user_followers_count) as impressions FROM {} WHERE track like '%Netflix%'".format(twitter_settings.TABLE_NAME)
    print('query: {0}'.format(query))
    back_up = pd.read_sql(query, con=conn)
    daily_tweets_num = back_up['daily_tweets_num'].iloc[0] #+ result[-6:-3]["Num of '{}' mentions".format(track_words[0])].sum()
    daily_impressions = 0 if back_up['impressions'].iloc[0]==None else  back_up['impressions'].iloc[0] #+ df[df['created_at'] > (datetime.datetime.now() - datetime.timedelta(hours=7, seconds=10))]['user_followers_count'].sum()
    print('daily_tweets_num: {0}'.format(daily_tweets_num))
    print('daily_impressions: {0}'.format(daily_impressions))

    # positive_count = df[df['polarity']==1]['id_str'].count()
    # negative_count = df[df['polarity']==-1]['id_str'].count()
    # neutral_count = df[df['polarity']==0]['id_str'].count()

    positive_count = result[result['polarity']==1]["Num of '{}' mentions".format(track_words[0])][result['polarity']==1].sum()
    negative_count = result[result['polarity']==-1]["Num of '{}' mentions".format(track_words[0])][result['polarity']==-1].sum()
    neutral_count = result[result['polarity']==0]["Num of '{}' mentions".format(track_words[0])][result['polarity']==0].sum()

    # values=[pos_num, neg_num, neu_num],
    # name="View Metrics",
    # marker_colors=['rgba(184, 247, 212, 0.6)','rgba(255, 50, 50, 0.6)','rgba(131, 90, 241, 0.6)'],
    total_tweets_df = pd.DataFrame(columns=['Polarity','Count'])
    total_tweets_df['Polarity'] = ['Positive','Negative','Neutral']
    total_tweets_df['Count'] = [positive_count,negative_count,neutral_count]
    total_tweets_df['Marker_Color'] = total_tweets_df['Polarity'].apply(lambda x: 'rgba(255, 50, 50, 0.6)' if x =='Negative' else \
        ('rgba(184, 247, 212, 0.6)' if x == 'Neutral' else 'rgba(131, 90, 241, 0.6)'))
    total_tweets_df['Line_Color'] = total_tweets_df['Polarity'].apply(lambda x: 'rgba(255, 50, 50, 1)' if x =='Negative' else \
        ('rgba(184, 247, 212, 1)' if x == 'Neutral' else 'rgba(131, 90, 241, 1)'))

    print('total tweets neu count: {0}'.format(neutral_count))
    print('total tweets neg count: {0}'.format(negative_count))
    print('total tweets pos count: {0}'.format(positive_count))


    cur = conn.cursor()

    # PDT_now = datetime.datetime.now() - datetime.timedelta(hours=7)
    # if PDT_now.strftime("%H%M")=='0000':
    #     cur.execute("UPDATE Back_Up SET daily_tweets_num = 0, impressions = 0;")
    # else:
    #     cur.execute("UPDATE Back_Up SET daily_tweets_num = {}, impressions = {};".format(daily_tweets_num, daily_impressions))
    conn.commit()
    cur.close()
    conn.close()

    # Percentage Number of Tweets changed in Last 10 mins

    count_now = df[df['created_at'] > min10]['id_str'].count()
    count_before = df[ (min20 <= df['created_at']) & (df['created_at'] < min10)]['id_str'].count()

    percent=0.0
    if(count_before>0):
        percent = (count_now-count_before)/count_before*100

    print('count now: {0}'.format(count_now))
    print('count_before: {0}'.format(count_before))
    print('pcnt: {0}'.format(percent))
    # Create the graph
    children = [
                html.Div([

                html.Div(
                    className='row',
                    children=[
                    html.Div(
                            children=[
                            ],
                            style={
                                'width': '20%',
                                'display': 'inline-block'
                            }
                        ),
                        html.Div(
                            children=[
                                html.P('Tweets Tracked Today',
                                    style={
                                        'fontSize': 20
                                    }
                                ),
                                html.P('{0:.1f}K'.format(daily_tweets_num/1000),
                                    style={
                                        'fontSize': 40
                                    }
                                )
                            ],
                            style={
                                'width': '40%',
                                'display': 'inline-block'
                            }
                        ),
                    html.Div(
                            children=[
                                html.P('Potential Impressions Today',
                                    style={
                                        'fontSize': 20
                                    }
                                ),
                                html.P('{0:.1f}K'.format(daily_impressions/1000) \
                                        if daily_impressions < 1000000 else \
                                            ('{0:.1f}M'.format(daily_impressions/1000000) if daily_impressions < 1000000000 \
                                            else '{0:.1f}B'.format(daily_impressions/1000000000)),
                                    style={
                                        'fontSize': 40
                                    }
                                )
                            ],
                            style={
                                'width': '40%',
                                'display': 'inline-block'
                            }
                        ),
                        # html.Div(
                        #         children=[
                        #         ],
                        #         style={
                        #             'width': '10%',
                        #             'display': 'inline-block'
                        #         }
                        #     ),

                    html.Div([
                        dcc.Graph(
                            id='tweets-time-series',
                            figure = {
                                'data':[
                                    go.Bar(
                                        x=total_tweets_df["Count"],
                                        y=total_tweets_df["Polarity"],#.loc[::-1],
                                        name="total_polarity",
                                        orientation='h',
                                        marker_color=total_tweets_df['Marker_Color'].loc[::-1].to_list(),
                                        marker=dict(
                                            line=dict(
                                                color=total_tweets_df['Line_Color'].loc[::-1].to_list(),
                                                width=0.6),
                                            ),
                                    )
                                ],
                                'layout':{
                                    'hovermode':"closest",
                                    'title':'Polarity of all Tweets tracked',
                                }
                            }
                        )
                    ], style={'width': '49%', 'display': 'inline-block', 'padding': '0 0 0 20'}),



                html.Div([
                    dcc.Graph(
                        id='pie-chart',
                        figure={
                            'data': [
                                go.Pie(
                                    labels=['Positives', 'Negatives', 'Neutrals'],
                                    values=[pos_num, neg_num, neu_num],
                                    name="View Metrics",
                                    marker_colors=['rgba(184, 247, 212, 0.6)','rgba(255, 50, 50, 0.6)','rgba(131, 90, 241, 0.6)'],
                                    textinfo='value',
                                    hole=.65)
                            ],
                            'layout':{
                                'showlegend':False,
                                'title':'Tweets In Last 10 Mins',
                                'annotations':[
                                    dict(
                                        text='{0:.1f}K'.format((pos_num+neg_num+neu_num)/1000),
                                        font=dict(
                                            size=40
                                        ),
                                        showarrow=False
                                    )
                                ]
                            }

                        }
                    )
                ], style={'width': '49%', 'display': 'inline-block'}),





                    html.Div([
                        dcc.Graph(
                            id='crossfilter-indicator-scatter',
                            figure={
                                'data': [
                                    go.Scatter(
                                        x=time_series,
                                        y=result["Num of '{}' mentions".format(track_words[0])][result['polarity']==0].reset_index(drop=True),
                                        name="Neutrals",
                                        opacity=0.8,
                                        mode='lines',
                                        line=dict(width=0.5, color='rgb(131, 90, 241)'),
                                        stackgroup='one'
                                    ),
                                    go.Scatter(
                                        x=time_series,
                                        y=result["Num of '{}' mentions".format(track_words[0])][result['polarity']==-1].reset_index(drop=True),#.apply(lambda x: -x),
                                        name="Negatives",
                                        opacity=0.8,
                                        mode='lines',
                                        line=dict(width=0.5, color='rgb(255, 50, 50)'),
                                        stackgroup='two'
                                    ),
                                    go.Scatter(
                                        x=time_series,
                                        y=result["Num of '{}' mentions".format(track_words[0])][result['polarity']==1].reset_index(drop=True),
                                        name="Positives",
                                        opacity=0.8,
                                        mode='lines',
                                        line=dict(width=0.5, color='rgb(184, 247, 212)'),
                                        stackgroup='three'
                                    )
                                ],
                                'layout':{
                                    'title':'Polarity of Tweets in timeframe of 1 hr group by 10 minutes'
                                    }
                            }
                        )
                    ], style={'width': '73%', 'display': 'inline-block', 'padding': '0 0 0 20'})
                ])
                    ],
                    style={'marginLeft': 70}
                )
            ]
    return children


@app.callback(Output('live-update-graph-bottom', 'children'),
              [Input('interval-component-slow', 'n_intervals')])
def update_graph_bottom_live(n):

    # Loading data from Heroku PostgreSQL
    DATABASE_URL = os.environ['DATABASE_URL']
    conn = psycopg2.connect(DATABASE_URL, sslmode='require')
    query = "SELECT id_str, text, created_at, polarity, user_location FROM {}".format(twitter_settings.TABLE_NAME)
    df = pd.read_sql(query, con=conn)
    conn.close()

    # Convert UTC into PDT
    df['created_at'] = pd.to_datetime(df['created_at']).apply(lambda x: x - datetime.timedelta(hours=7))

    # positive_count = df[df['polarity']==1]['id_str'].count()
    # negative_count = df[df['polarity']==-1]['id_str'].count()
    # neutral_count = df[df['polarity']==0]['id_str'].count()


    # Clean and transform data to enable word frequency
    content = ' '.join(df["text"])
    content = re.sub(r"http\S+", "", content)
    content = content.replace('RT ', ' ').replace('&amp;', 'and')
    content = content.replace('amp ', '')
    content = re.sub('[^A-Za-z0-9]+', ' ', content)
    content = content.lower()

    # Filter constants for states in US
    STATES = ['Alabama', 'AL', 'Alaska', 'AK', 'American Samoa', 'AS', 'Arizona', 'AZ', 'Arkansas', 'AR', 'California', 'CA', 'Colorado', 'CO', 'Connecticut', 'CT', 'Delaware', 'DE', 'District of Columbia', 'DC', 'Federated States of Micronesia', 'FM', 'Florida', 'FL', 'Georgia', 'GA', 'Guam', 'GU', 'Hawaii', 'HI', 'Idaho', 'ID', 'Illinois', 'IL', 'Indiana', 'IN', 'Iowa', 'IA', 'Kansas', 'KS', 'Kentucky', 'KY', 'Louisiana', 'LA', 'Maine', 'ME', 'Marshall Islands', 'MH', 'Maryland', 'MD', 'Massachusetts', 'MA', 'Michigan', 'MI', 'Minnesota', 'MN', 'Mississippi', 'MS', 'Missouri', 'MO', 'Montana', 'MT', 'Nebraska', 'NE', 'Nevada', 'NV', 'New Hampshire', 'NH', 'New Jersey', 'NJ', 'New Mexico', 'NM', 'New York', 'NY', 'North Carolina', 'NC', 'North Dakota', 'ND', 'Northern Mariana Islands', 'MP', 'Ohio', 'OH', 'Oklahoma', 'OK', 'Oregon', 'OR', 'Palau', 'PW', 'Pennsylvania', 'PA', 'Puerto Rico', 'PR', 'Rhode Island', 'RI', 'South Carolina', 'SC', 'South Dakota', 'SD', 'Tennessee', 'TN', 'Texas', 'TX', 'Utah', 'UT', 'Vermont', 'VT', 'Virgin Islands', 'VI', 'Virginia', 'VA', 'Washington', 'WA', 'West Virginia', 'WV', 'Wisconsin', 'WI', 'Wyoming', 'WY']
    STATE_DICT = dict(itertools.zip_longest(*[iter(STATES)] * 2, fillvalue=""))
    INV_STATE_DICT = dict((v,k) for k,v in STATE_DICT.items())

    # Clean and transform data to enable geo-distribution
    is_in_US=[]
    geo = df[['user_location']]
    df = df.fillna(" ")
    for x in df['user_location']:
        check = False
        for s in STATES:
            if s in x:
                is_in_US.append(STATE_DICT[s] if s in STATE_DICT else s)
                check = True
                break
        if not check:
            is_in_US.append(None)

    geo_dist = pd.DataFrame(is_in_US, columns=['State']).dropna().reset_index()
    geo_dist = geo_dist.groupby('State').count().rename(columns={"index": "Number"}) \
        .sort_values(by=['Number'], ascending=False).reset_index()
    geo_dist["Log Num"] = geo_dist["Number"].apply(lambda x: math.log(x, 2))

    geo_dist['Full State Name'] = geo_dist['State'].apply(lambda x: INV_STATE_DICT[x])
    geo_dist['text'] = geo_dist['Full State Name'] + '<br>' + 'Num: ' + geo_dist['Number'].astype(str)
    #geo_dist['text'] = geo_dist['Full State Name'] + '<br>' + 'Pos: ' + positive_count.astype(str) + '<br>' + 'Neg: ' + negative_count.astype(str) + '<br>' + 'Neu: ' + neutral_count.astype(str)

    # def geo_polarity(text):
    #     if text in df['user_location']:



    tokenized_word = word_tokenize(content)
    stop_words=stopwords.words("english")
    stop_words.extend(['netflix','disney','disneyplus','amazon','amazonprime'])
    filtered_sent=[]
    for w in tokenized_word:
        if (w not in stop_words) and (len(w) >= 3):
            filtered_sent.append(w)
    fdist = FreqDist(filtered_sent)

    def vader_score(text):

        analyser11 = SentimentIntensityAnalyzer()
        tt_score = analyser11.polarity_scores(text)
        return tt_score['compound']
    #trial_score = trial_score_check("good")
    # labels=['Positives', 'Negatives', 'Neutrals'],
    # values=[pos_num, neg_num, neu_num],
    # name="View Metrics",
    # marker_colors=['rgba(184, 247, 212, 0.6)','rgba(255, 50, 50, 0.6)','rgba(131, 90, 241, 0.6)'],
    # if score['compound']>=0.05: #positive
    #     polarity = 1
    # elif (score['compound']>-0.05) & (score['compound']<0.05): #neutral
    #     polarity = 0
    # elif score['compound']<=-0.05: #negative
    #     polarity = -1

    fd = pd.DataFrame(fdist.most_common(16), columns = ["Word","Frequency"]).drop([0]).reindex()
    fd['Compound_Score'] = fd['Word'].apply(vader_score)
    print('Compound Score: {0}'.format(fd['Compound_Score'][1]))
    fd['Marker_Color'] = fd['Compound_Score'].apply(lambda x: 'rgba(255, 50, 50, 0.6)' if x < -0.05 else \
        ('rgba(184, 247, 212, 0.6)' if x >= 0.05 else 'rgba(131, 90, 241, 0.6)'))
    fd['Line_Color'] = fd['Compound_Score'].apply(lambda x: 'rgba(255, 50, 50, 1)' if x < -0.05 else \
        ('rgba(184, 247, 212, 1)' if x >= 0.05 else 'rgba(131, 90, 241, 1)'))

    # fd = pd.DataFrame(fdist.most_common(16), columns = ["Word","Frequency"]).drop([0]).reindex()
    # fd['Polarity'] = fd['Word'].apply(lambda x: TextBlob(x).sentiment.polarity)
    # fd['Marker_Color'] = fd['Polarity'].apply(lambda x: 'rgba(255, 50, 50, 0.6)' if x < -0.1 else \
    #     ('rgba(184, 247, 212, 0.6)' if x > 0.1 else 'rgba(131, 90, 241, 0.6)'))
    # fd['Line_Color'] = fd['Polarity'].apply(lambda x: 'rgba(255, 50, 50, 1)' if x < -0.1 else \
    #     ('rgba(184, 247, 212, 1)' if x > 0.1 else 'rgba(131, 90, 241, 1)'))



    # Create the graph
    children = [
                # html.Div(
                #         children=[
                #         ],
                #         style={
                #             'width': '10%',
                #             'display': 'inline-block'
                #         }
                #     ),
                html.Div([
                    dcc.Graph(
                        id='x-time-series',
                        figure = {
                            'data':[
                                go.Bar(
                                    x=fd["Frequency"].loc[::-1],
                                    y=fd["Word"].loc[::-1],
                                    name="Neutrals",
                                    orientation='h',
                                    marker_color=fd['Marker_Color'].loc[::-1].to_list(),
                                    marker=dict(
                                        line=dict(
                                            color=fd['Line_Color'].loc[::-1].to_list(),
                                            width=1),
                                        ),
                                )
                            ],
                            'layout':{
                                'hovermode':"closest",
                                'title':"Most frequent topics"
                            }
                        }
                    )
                ], style={'width': '49%', 'display': 'inline-block' , 'padding': '0 0 0 20'}),
                html.Div([
                    dcc.Graph(
                        id='y-time-series',
                        figure = {
                            'data':[
                                go.Choropleth(
                                    locations=geo_dist['State'], # Spatial coordinates
                                    z = geo_dist['Log Num'].astype(float), # Data to be color-coded
                                    locationmode = 'USA-states', # set of locations match entries in `locations`
                                    #colorscale = "Blues",
                                    text=geo_dist['text'], # hover text
                                    geo = 'geo',
                                    colorbar_title = "Num in Log2",
                                    marker_line_color='white',
                                    colorscale = ["#fdf7ff", "#835af1"],
                                    #autocolorscale=False,
                                    #reversescale=True,
                                )
                            ],
                            'layout': {
                                'title': "Geographic Segmentation for US",
                                'geo':{'scope':'usa'}
                            }
                        }
                    )
                ], style={'display': 'inline-block', 'width': '49%'})
            ]

    return children





if __name__ == '__main__':
    app.run_server(debug=True)
